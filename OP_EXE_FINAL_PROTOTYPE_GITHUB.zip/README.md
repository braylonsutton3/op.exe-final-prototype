# OP.exe Quant

OP.exe Quant is a read-only market decision-support dashboard. It reports an
independent **LONG**, **SHORT**, or **WAIT** result for 1m, 5m, 30m, 1h, 4h,
and 1d. Qualified plans include an entry, volatility/structure-based stop,
liquidity target, estimated target-first probability, conservative probability
lower bound, expected value in R, and projected dollar risk/reward.

It is intentionally selective. A Monte Carlo result cannot create a trade by
itself: the structural engine must qualify first, then the statistical gates may
accept it or downgrade it to WAIT.

## Analysis layers

- EMA 20/50/200 trend and regime
- RSI, ADX, volume expansion, ATR, and session VWAP
- Confirmed swings, break of structure, liquidity sweeps, and displacement
- Fair-value gaps and higher-timeframe alignment
- Prior-day, prior-week, overnight, RTH, 9:30 open, and opening-range levels
- Regime-conditioned block-bootstrap Monte Carlo paths
- Historical volatility- and direction-matched barrier analogues
- Optional current order-book imbalance, delta, aggression, and absorption
- Fresh-feed, minimum reward/risk, maximum-dollar-risk, and cost gates
- One tracked position at a time; new trades stay locked until it closes

Quality is confluence, not win probability. The displayed probability is an
estimate from resampled history and historical analogues, not certainty.

## Files

- `main.py` — Streamlit dashboard
- `op_engine.py` — structural and risk engine
- `quant_engine.py` — Monte Carlo and historical-analogue validation
- `backtest.py` — conservative supplied-file test
- `quant_backtest.py` — experimental higher-frequency research test
- `QUANT_VALIDATION.md` — methods, results, and limitations
- `requirements.txt` and `render.yaml` — deployment configuration

## Deploy on Render

Put all files in one GitHub repository. Render can read `render.yaml`, or use:

```text
Build command: pip install -r requirements.txt
Start command: streamlit run main.py --server.port $PORT --server.address 0.0.0.0
```

For ProjectX / TopstepX bar data, set these as private Render environment
variables (never commit credentials):

```text
TOPSTEP_USERNAME=your_username
TOPSTEP_API_KEY=your_api_key
```

Without them, the app attempts a Yahoo fallback. That fallback may be delayed
and is not suitable for exchange-grade execution decisions. The code is
read-only and contains no order-placement endpoint.

## Asset settings

Enter a ProjectX contract search term or a Yahoo symbol. Examples include MNQ,
MES, AAPL, SPY, and BTC-USD. Set the instrument's actual minimum price increment
and dollar value per increment. Defaults are MNQ: 0.25 tick and $0.50 per tick.

## Optional order-flow bridge

Bookmap, MarketBook, Databento, or another depth process can expose a secured
JSON snapshot endpoint. Configure private environment variables:

```text
ORDERFLOW_BRIDGE_URL=https://your-private-bridge/snapshot
ORDERFLOW_BRIDGE_TOKEN=your_private_token
```

Expected JSON:

```json
{
  "timestamp": "2026-09-20T14:30:00Z",
  "bid_depth": 1280,
  "ask_depth": 910,
  "delta_1m": 325,
  "aggressive_buy": 620,
  "aggressive_sell": 390,
  "absorption_bid": true,
  "absorption_ask": false
}
```

The supplied NQ file has candles and volume but no historical depth-of-book.
Consequently, the historical results do not validate the order-flow layer. Live
order-flow snapshots must be recorded and tested before relying on that filter.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run main.py
```

Run the conservative historical test:

```bash
python backtest.py "Dataset_NQ_1min_2022_2025(2).csv"
```

Run the experimental multi-trade research test:

```bash
python quant_backtest.py "Dataset_NQ_1min_2022_2025(2).csv"
```

No strategy can guarantee profit, monthly profitability, fills, or a fixed
accuracy. Use paper trading and forward validation before risking capital.
